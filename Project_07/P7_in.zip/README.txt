input files for this project are to be used for redirected input
there are two types of input files provided.
Input files P7_in1.txt - P7_in7.txt are to be used for
redirected input:
./Project_07 < P7_in1.txt

the input files P7_in11.txt - P7_in55.txt are
the actual input files used by the program.  These are
the files that contain the characters that are to be 
processed.

The comparison script uses input files P7_in1 - P7_in7 for
redirected input.  These 7 files have all of the entries
that would normally have to be typed into the program - i.e.
the menu choices, the name of the input file, etc.

Only use P7_in1.txt - P7_in7.txt for redirected input
