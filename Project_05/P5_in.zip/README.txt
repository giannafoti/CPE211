For this program, command line arguments are used to
pass in the input and output file names.  The
way to run your program is as shown below:

./Project_05 input_file_name  output_file_name

The order must be input file first and then output file

Look at the command line argument slides for more information

