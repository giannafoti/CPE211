The input files provided are for redirected input use only.
To perform redirected input use the following format

>> g++ -std=c++11 Project_03.cpp -o Project_03
>> ./Project_03 < P3_in1.txt

Where P3_in1.txt is the name of the file to use for
redirected input.  The same procedure can be done
with the other input files.

