For input files provided, 
use redirected input to have your 
program read the values.

if your program source code is Project_04.cpp
Then compile the code using the command:
g++ -std=c++11 Project_04.cpp -o Project_04

Alternatively, a Makefile has been provided that
will perform the compiling of your program to
generate the executable.  to run the Makefile,
just type make on the command line.
for example:
bash4-2$ make

To run your program, type the following command:
./Project_04

To run your program using redirected input with
the input files, use the commands
./Project_04 < P4_in1.txt 
or
./Project_04 < P4_in2.txt
or
./Project_04 < P4_in3.txt



